from django.contrib.auth.models import User
from django.db import models


class MobileBrand(models.Model):
    brand_name=models.CharField(max_length=100)

class MobileData(models.Model):
    brand=models.ForeignKey(MobileBrand,on_delete=models.CASCADE)
    name=models.CharField(max_length=100)
    image=models.ImageField(upload_to='mobiles/')
    description=models.TextField()

