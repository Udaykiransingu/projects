from django.contrib.auth.models import User
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .models import MobileBrand, MobileData
import requests
import pandas as pd
from bs4 import BeautifulSoup

def login_page(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            return redirect('home')
        else:
            return render(request, 'login.html', {'error': 'Invalid credentials'})
    return render(request, 'login.html')

def register_page(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        email = request.POST['email']
        user = User.objects.create_user(username=username, password=password, email=email)
        return redirect('login')
    return render(request, 'register.html')

@login_required
def home_page(request):
   
    url="https://www.flipkart.com/search?sid=tyy%2C4io&otracker=CLP_Filters&p%5B%5D=facets.brand%255B%255D%3DApple&p%5B%5D=facets.brand%255B%255D%3DSAMSUNG&p%5B%5D=facets.brand%255B%255D%3Dvivo"
    response = requests.get(url)
    soup = BeautifulSoup(response.content,'html.parser')
    names= soup.find_all('div',class_="KzDlHZ")
    name=[]
    for i in names:
        d=i.get_text()
        name.append(d)

    prices= soup.find_all('div',class_="Nx9bqj _4b5DiR")
    price=[]
    for i in prices:
        d=i.get_text()
        price.append(d)
    
    images= soup.find_all('img',class_="DByuf4")
    image=[]
    for i in images:
        d=i['src']
        image.append(d)

    mylist=zip(name,price,image)
    return render(request, 'home.html', {'mylist':mylist})

@login_required
def logout_view(request):
    logout(request)
    return redirect('login')



@login_required
def Mi(request):
    

    url3="https://www.flipkart.com/mobiles/mi~brand/pr?sid=tyy,4io&otracker=nmenu_sub_Electronics_0_Mi"
    response3 = requests.get(url3)
    soup3 = BeautifulSoup(response3.content,'html.parser')
    names3= soup3.find_all('div',class_="KzDlHZ")
    name3=[]
    for i in names3:
        d=i.get_text()
        name3.append(d)

    prices3= soup3.find_all('div',class_="Nx9bqj _4b5DiR")
    price3=[]
    for i in prices3:
        d=i.get_text()
        price3.append(d)
    
    images3= soup3.find_all('img',class_="DByuf4")
    image3=[]
    for i in images3:
        d=i['src']
        image3.append(d)

    mylist3=zip(name3,price3,image3)
    return render(request,"Mi.html",{'mylist3':mylist3})

@login_required
def Apple(request):

    url1="https://www.flipkart.com/search?q=apple+mobiles&sid=tyy%2C4io&as=on&as-show=on&otracker=AS_QueryStore_OrganicAutoSuggest_1_7_na_na_na&otracker1=AS_QueryStore_OrganicAutoSuggest_1_7_na_na_na&as-pos=1&as-type=RECENT&suggestionId=apple+mobiles%7CMobiles&requestId=74513d15-9fcc-41ea-a7e0-16499e689ee3&as-backfill=on&otracker=nmenu_sub_Electronics_0_Apple"
    response1= requests.get(url1)
    soup1 = BeautifulSoup(response1.content,'html.parser')
    names1 = soup1.find_all('div',class_="KzDlHZ")
    name1 = []
    for i in names1:
        d=i.get_text()
        name1.append(d)
    

    prices1= soup1.find_all('div',class_="Nx9bqj _4b5DiR")
    price1=[]
    for i in prices1:
        d=i.get_text()
        price1.append(d)
    
    images1 = soup1.find_all('img',class_="DByuf4")
    image1=[]
    for i in images1:
        d=i['src']
        image1.append(d)
    

    mylist1=zip(name1,price1,image1)


    return render(request,"Apple.html",{"mylist1":mylist1})

@login_required
def Poco(request):

    url2="https://www.flipkart.com/search?q=poco+x2&sid=tyy%2C4io&as=on&as-show=on&otracker=AS_QueryStore_OrganicAutoSuggest_1_7_na_na_ps&otracker1=AS_QueryStore_OrganicAutoSuggest_1_7_na_na_ps&as-pos=1&as-type=RECENT&suggestionId=poco+x2%7CMobiles&requestId=408349ea-12b0-4080-8082-5a58a60f6e52&as-backfill=on&otracker=nmenu_sub_Electronics_0_Poco%20X2"
    response2 = requests.get(url2)
    soup2 = BeautifulSoup(response2.content,'html.parser')
    names2=soup2.find_all('div',class_="KzDlHZ")
    name2=[]
    for i in names2:
        d=i.get_text()
        name2.append(d)

    prices2= soup2.find_all('div',class_="Nx9bqj _4b5DiR")
    price2=[]
    for i in prices2:
        d=i.get_text()
        price2.append(d)
    

    images2 = soup2.find_all('img',class_="DByuf4")
    image2=[]
    for i in images2:
        d=i['src']
        image2.append(d)

    mylist2=zip(name2,price2,image2)


    return render(request,"Poco.html",{'mylist2':mylist2})